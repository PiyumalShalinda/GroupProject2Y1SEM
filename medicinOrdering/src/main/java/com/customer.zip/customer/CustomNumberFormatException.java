package com.customer;

/**
 * Custom exception class for handling number format errors in contact numbers.
 * Extends the RuntimeException class to create an unchecked exception.
 */
public class CustomNumberFormatException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    /**
     * Constructs a new CustomNumberFormatException with null as its detail message.
     */
    public CustomNumberFormatException() {
        super();
    }

    /**
     * Constructs a new CustomNumberFormatException with the specified detail message.
     * 
     * @param message the detail message
     */
    public CustomNumberFormatException(String message) {
        super(message);
    }

    /**
     * Constructs a new CustomNumberFormatException with the specified detail message and cause.
     * 
     * @param message the detail message
     * @param cause the cause of the exception
     */
    public CustomNumberFormatException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Constructs a new CustomNumberFormatException with the specified cause.
     * 
     * @param cause the cause of the exception
     */
    public CustomNumberFormatException(Throwable cause) {
        super(cause);
    }
}